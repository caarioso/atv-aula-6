// Classe para Orçamento de Projetos
class Orcamento {
    constructor(nome, descricao, custoPorHora, horasEstimadas) {
        this.nome = nome;
        this.descricao = descricao;
        this.custoPorHora = parseFloat(custoPorHora);
        this.horasEstimadas = parseFloat(horasEstimadas);
        this.custoTotal = this.calcularCustoTotal();
        this.dataCadastro = new Date().toLocaleString();
    }

    // Método para calcular o custo total
    calcularCustoTotal() {
        return (this.custoPorHora * this.horasEstimadas).toFixed(2);
    }
}

// Função para adicionar um novo orçamento
function adicionarOrcamento(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value;
    const descricao = document.getElementById('descricao').value;
    const custoPorHora = document.getElementById('custoPorHora').value;
    const horasEstimadas = document.getElementById('horasEstimadas').value;

    const orcamento = new Orcamento(nome, descricao, custoPorHora, horasEstimadas);
    
    // Adicionar à tabela
    const table = document.getElementById('orcamentosTable').getElementsByTagName('tbody')[0];
    const newRow = table.insertRow();
    newRow.innerHTML = `
        <td>${orcamento.nome}</td>
        <td>${orcamento.descricao}</td>
        <td>R$ ${orcamento.custoPorHora}</td>
        <td>${orcamento.horasEstimadas}</td>
        <td>R$ ${orcamento.custoTotal}</td>
        <td>${orcamento.dataCadastro}</td>
        <td><button class="action-btn" onclick="removerOrcamento(this)">Remover</button></td>
    `;

    // Limpar o formulário
    document.getElementById('formOrcamento').reset();
}

// Função para remover um orçamento
function removerOrcamento(button) {
    const row = button.parentElement.parentElement;
    row.remove();
}

// Adicionar evento de submit para o formulário
document.getElementById('formOrcamento').addEventListener('submit', adicionarOrcamento);
